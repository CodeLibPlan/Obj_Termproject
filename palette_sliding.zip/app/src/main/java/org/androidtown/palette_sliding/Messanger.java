package org.androidtown.palette_sliding;

import android.os.Message;

/**
 * Created by chm31 on 2017-11-26.
 */

public interface Messanger {
    void receive(Message m);
}
