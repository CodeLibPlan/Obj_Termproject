package org.androidtown.palette_sliding;

/**
 * Created by chm31 on 2017-11-26.
 */

public class NetworkSender extends Thread implements BackgroundSender {

    @Override
    public void run() {

    }
    @Override
    public void send(String s) {
        // TODO Auto-generated method stub

    }
}
