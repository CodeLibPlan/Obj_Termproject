package org.androidtown.palette_sliding;

/**
 * Created by chm31 on 2017-11-26.
 */

public interface BackgroundListener {
    public void start();
    public void callback(CallbackEvent ev);
    //void receive(Message m);
}
