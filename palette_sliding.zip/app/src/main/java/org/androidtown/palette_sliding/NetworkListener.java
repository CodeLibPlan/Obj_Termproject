package org.androidtown.palette_sliding;

/**
 * Created by chm31 on 2017-11-26.
 */

public class NetworkListener extends Thread implements BackgroundListener {
    @Override
    public void run() {

    }
    @Override
    public void callback(CallbackEvent ev) {
        // TODO Auto-generated method stub

    }
}
