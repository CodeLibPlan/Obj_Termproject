package org.androidtown.palette_sliding;

/**
 * Created by chm31 on 2017-11-26.
 */

public interface CallbackEvent {
    /* *
     * 이 클래스를 상속하여 run()함수를 재정의한 후 인자로 넘길 수 있음.
     * */
    public void run(String input);
}

